/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.classe;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Query;
import javax.persistence.SequenceGenerator;

/**
 *
 * @author Caio
 */
@NamedQueries({
    @NamedQuery(name="email",
                query="SELECT c FROM Country c"),
    @NamedQuery(name="senha",
                query="SELECT c FROM Country c WHERE c.name = :name"),
}) 

@Entity
@SequenceGenerator(name="seq_log", sequenceName="seq_log", allocationSize = 1,initialValue = 1 )
public class Login extends Cadastro{
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_log")
    
    @Column(nullable = false)
    private String email;
    @Column(nullable = false)
    private String senha;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
}