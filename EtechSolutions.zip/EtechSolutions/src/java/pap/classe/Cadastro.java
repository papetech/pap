/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.classe;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 *
 * @author Caio
 */
@Entity
@SequenceGenerator(name="seq_cad", sequenceName="seq_cad", allocationSize = 1,initialValue = 1 )
//@NamedQueries({@NamedQuery(name = "123", query = "select l from Livro")})
public class Cadastro implements Serializable{
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cad")
    
        @Column(nullable = false)
        @Id
        private Long id;        
        //Dados Pessoais 
        @Column(nullable = false)
        private String nome;
        @Column(nullable = false)
        private String sobreNome;
        @Column(nullable = false)
        private String cpf;
        @Column(nullable = false)
        @Temporal(TemporalType.DATE)
        private Date dtNascimento;
        @Column(nullable = false)
        private String sexo;
        @Column(nullable = false)
        private String telefone;
        @OneToOne
        private Endereco endereco;
        
        
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobreNome() {
        return sobreNome;
    }

    public void setSobreNome(String sobreNome) {
        this.sobreNome = sobreNome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getDtNascimento() {
        return dtNascimento;
    }

    public void setDtNascimento(Date dtNascimento) {
        this.dtNascimento = dtNascimento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }
        
}

