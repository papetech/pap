/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.classe;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 *
 * @author Caio
 */
@Entity
@SequenceGenerator(name="seq_cad", sequenceName="seq_cad", allocationSize = 1,initialValue = 1 )
//@NamedQueries({@NamedQuery(name = "123", query = "select l from Livro")})
public class Pagamento extends Compra{
    //@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cad")
        
        @Column(nullable = false)
        private double valor;
        @Column(nullable = false)
        private String idCliente;
        @Column
        private Long idCompra;

        
    public Long getId() {
        return getCodProduto();
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public Long getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(Long idCompra) {
        this.idCompra = idCompra;
    }
        
        
}

