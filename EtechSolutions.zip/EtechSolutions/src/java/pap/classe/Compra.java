/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.classe;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 *
 * @author Caio
 */
@Entity
@SequenceGenerator(name="seq_comp", sequenceName="seq_comp", allocationSize = 1,initialValue = 1 )
//@NamedQueries({@NamedQuery(name = "123", query = "select l from Livro")})
public class Compra implements Serializable{
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_comp")
    
    @Column(nullable = false)
    @Id
    private Long codProduto;
    @Column(nullable = false)
    private int qtdProduto;
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dtEmissao;
    @Column
    private double valorTotal;

    public Long getCodProduto() {
        return codProduto;
    }

    public void setCodProduto(Long codProduto) {
        this.codProduto = codProduto;
    }

    public int getQtdProduto() {
        return qtdProduto;
    }

    public void setQtdProduto(int qtdProduto) {
        this.qtdProduto = qtdProduto;
    }

    public Date getDtEmissao() {
        return dtEmissao;
    }

    public void setDtEmissao(Date dtEmissao) {
        this.dtEmissao = dtEmissao;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }
    
    

}

