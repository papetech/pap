/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.classe;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 *
 * @author Caio
 */
@Entity
@SequenceGenerator(name="seq_ing", sequenceName="seq_ing", allocationSize = 1,initialValue = 1 )
//@NamedQueries({@NamedQuery(name = "123", query = "select l from Livro")})
public class Ingresso implements Serializable{
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_ing")
    
    @Column(nullable = false)
    @Id
    private Long id;
    @Column(nullable = false)
    private String banda;
    @Column(nullable = false)
    private double preco;
    @Column(nullable = false)
    private String localidade;
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dtShow;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBanda() {
        return banda;
    }

    public void setBanda(String banda) {
        this.banda = banda;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getLocalidade() {
        return localidade;
    }

    public void setLocalidade(String localidade) {
        this.localidade = localidade;
    }

    public Date getDtShow() {
        return dtShow;
    }

    public void setDtShow(Date dtShow) {
        this.dtShow = dtShow;
    }
        
        
}

