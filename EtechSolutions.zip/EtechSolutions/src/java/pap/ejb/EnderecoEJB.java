/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;

import pap.classe.Endereco;
import pap.dao.EnderecoDAO;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Caio
 */

@Stateless
public class EnderecoEJB implements EnderecoRemote{
	@PersistenceContext(unitName = "etechPU")
	private EntityManager em;

        @Override
	public Endereco salvar(Endereco l){
	EnderecoDAO dao = new EnderecoDAO(em);
	return dao.salvar(l);
}        
        @Override
	public Endereco consultarPorId(Long Id){
	EnderecoDAO dao = new EnderecoDAO(em);
	return dao.consultarPorId(Id);
}
        @Override
	public void remover(Long Id){
	EnderecoDAO dao = new EnderecoDAO(em);
	dao.remover(Id);
}
}
