/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;
import pap.classe.Ingresso;
import javax.ejb.Remote;

/**
 *
 * @author Caio
 */

@Remote
public interface IngressoRemote{
	public Ingresso salvar(Ingresso l);
	public Ingresso consultarPorId(Long id);
	public void remover(Long id);
}
