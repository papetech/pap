/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;
import java.util.List;
import javax.ejb.Remote;
import pap.classe.Login;

/**
 *
 * @author Caio
 */

@Remote
public interface LoginRemote{
	public List<String> consultarEmail(String Email);
	public List<String> consultarSenha(String Senha);
}
