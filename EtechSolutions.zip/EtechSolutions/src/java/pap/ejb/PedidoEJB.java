/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;

import pap.classe.Pedido;
import pap.dao.PedidoDAO;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Caio
 */

@Stateless
public class PedidoEJB implements PedidoRemote{
	@PersistenceContext(unitName = "etechPU")
	private EntityManager em;

        @Override
	public Pedido salvar(Pedido l){
	PedidoDAO dao = new PedidoDAO(em);
	return dao.salvar(l);
}        
        @Override
	public Pedido consultarPorId(Long Id){
	PedidoDAO dao = new PedidoDAO(em);
	return dao.consultarPorId(Id);
}
        @Override
	public void remover(Long Id){
	PedidoDAO dao = new PedidoDAO(em);
	dao.remover(Id);
}

}
