/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;

import pap.classe.Ingresso;
import pap.dao.IngressoDAO;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Caio
 */

@Stateless
public class IngressoEJB implements IngressoRemote{
	@PersistenceContext(unitName = "etechPU")
	private EntityManager em;

        @Override
	public Ingresso salvar(Ingresso l){
	IngressoDAO dao = new IngressoDAO(em);
	return dao.salvar(l);
}        
        @Override
	public Ingresso consultarPorId(Long Id){
	IngressoDAO dao = new IngressoDAO(em);
	return dao.consultarPorId(Id);
}
        @Override
	public void remover(Long Id){
	IngressoDAO dao = new IngressoDAO(em);
	dao.remover(Id);
}

}
