/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;
import pap.classe.Compra;
import javax.ejb.Remote;

/**
 *
 * @author Caio
 */

@Remote
public interface CompraRemote{
	public Compra salvar(Compra l);
	public Compra consultarPorId(Long id);
	public void remover(Long id);
}
