/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;
import javax.ejb.Remote;
import pap.classe.Endereco;

/**
 *
 * @author Caio
 */

@Remote
public interface EnderecoRemote{
	public Endereco salvar(Endereco l);
	public Endereco consultarPorId(Long id);
	public void remover(Long id);
}
