/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;

import pap.classe.Compra;
import pap.dao.CompraDAO;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Caio
 */

@Stateless
public class CompraEJB implements CompraRemote{
	@PersistenceContext(unitName = "etechPU")
	private EntityManager em;

        @Override
	public Compra salvar(Compra l){
	CompraDAO dao = new CompraDAO(em);
	return dao.salvar(l);
}        
        @Override
	public Compra consultarPorId(Long Id){
	CompraDAO dao = new CompraDAO(em);
	return dao.consultarPorId(Id);
}
        @Override
	public void remover(Long Id){
	CompraDAO dao = new CompraDAO(em);
	dao.remover(Id);
}

}
