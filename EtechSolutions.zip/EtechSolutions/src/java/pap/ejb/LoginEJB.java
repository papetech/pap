/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;

import java.util.List;
import pap.classe.Login;
import pap.dao.LoginDAO;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Caio
 */

@Stateless
public class LoginEJB implements LoginRemote{
	@PersistenceContext(unitName = "etechPU")
	private EntityManager em;

    @Override
    public List<String> consultarEmail(String Email) {
        LoginDAO dao = new LoginDAO(em);
        return dao.consultarEmail(Email);
    }

    @Override
    public List<String> consultarSenha(String Senha) {
        LoginDAO dao = new LoginDAO(em);
        return dao.consultarSenha(Senha);
    }
}
