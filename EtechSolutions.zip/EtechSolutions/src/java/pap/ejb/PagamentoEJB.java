/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;

import pap.classe.Pagamento;
import pap.dao.PagamentoDAO;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Caio
 */

@Stateless
public class PagamentoEJB implements PagamentoRemote{
	@PersistenceContext(unitName = "etechPU")
	private EntityManager em;

        @Override
	public Pagamento salvar(Pagamento l){
	PagamentoDAO dao = new PagamentoDAO(em);
	return dao.salvar(l);
}        
        @Override
	public Pagamento consultarPorId(Long Id){
	PagamentoDAO dao = new PagamentoDAO(em);
	return dao.consultarPorId(Id);
}
        @Override
	public void remover(Long Id){
	PagamentoDAO dao = new PagamentoDAO(em);
	dao.remover(Id);
}

}
