/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;
import pap.classe.Pedido;
import javax.ejb.Remote;

/**
 *
 * @author Caio
 */

@Remote
public interface PedidoRemote{
	public Pedido salvar(Pedido l);
	public Pedido consultarPorId(Long id);
	public void remover(Long id);
}
