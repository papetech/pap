/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.ejb;

import pap.classe.Cadastro;
import pap.dao.CadastroDAO;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Caio
 */

@Stateless
public class CadastroEJB implements CadastroRemote{
	@PersistenceContext(unitName = "etechPU")
	private EntityManager em;

        @Override
	public Cadastro salvar(Cadastro l){
	CadastroDAO dao = new CadastroDAO(em);
	return dao.salvar(l);
}        
        @Override
	public Cadastro consultarPorId(Long Id){
	CadastroDAO dao = new CadastroDAO(em);
	return dao.consultarPorId(Id);
}
        @Override
	public void remover(Long Id){
	CadastroDAO dao = new CadastroDAO(em);
	dao.remover(Id);
}

}
