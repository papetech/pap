/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.dao;

import pap.classe.Compra;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author Caio
 */
public class CompraDAO{

	private EntityManager em;

	public CompraDAO(EntityManager em){
		this.em = em;
	}
	
	public Compra salvar(Compra l){
	if(l.getCodProduto() == null){
            em.persist(l);
}else{
	l = em.merge(l);
}
	return l;}

	public Compra consultarPorId(Long id){
	return em.find(Compra.class, id);}
	
	public void remover(Long id){
	Compra l = em.find(Compra.class,id);
	em.remove(l);}
        
        public List<Compra> consultar(){
        Query q =  em.createNamedQuery("123");
        return q.getResultList();
        }
}