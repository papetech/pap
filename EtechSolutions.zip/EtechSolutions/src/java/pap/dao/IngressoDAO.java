/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.dao;

import pap.classe.Ingresso;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author Caio
 */
public class IngressoDAO{

	private EntityManager em;

	public IngressoDAO(EntityManager em){
		this.em = em;
	}
	
	public Ingresso salvar(Ingresso l){
	if(l.getId() == null){
            em.persist(l);
}else{
	l = em.merge(l);
}
	return l;}

	public Ingresso consultarPorId(Long id){
	return em.find(Ingresso.class, id);}
	
	public void remover(Long id){
	Ingresso l = em.find(Ingresso.class,id);
	em.remove(l);}
        
        public List<Ingresso> consultar(){
        Query q =  em.createNamedQuery("123");
        return q.getResultList();
        }
}