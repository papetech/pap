/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.dao;

import pap.classe.Cadastro;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author Caio
 */
public class CadastroDAO{

	private EntityManager em;

	public CadastroDAO(EntityManager em){
		this.em = em;
	}
	
	public Cadastro salvar(Cadastro l){
	if(l.getId() == null){
            em.persist(l);
}else{
	l = em.merge(l);
}
	return l;}

	public Cadastro consultarPorId(Long id){
	return em.find(Cadastro.class, id);}
	
	public void remover(Long id){
	Cadastro l = em.find(Cadastro.class,id);
	em.remove(l);}
        
        public List<Cadastro> consultar(){
        Query q =  em.createNamedQuery("123");
        return q.getResultList();
        }
}