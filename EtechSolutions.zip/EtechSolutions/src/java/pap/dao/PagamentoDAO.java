/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.dao;

import pap.classe.Pagamento;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author Caio
 */
public class PagamentoDAO{

	private EntityManager em;

	public PagamentoDAO(EntityManager em){
		this.em = em;
	}
	
	public Pagamento salvar(Pagamento l){
	if(l.getId() == null){
            em.persist(l);
}else{
	l = em.merge(l);
}
	return l;}

	public Pagamento consultarPorId(Long id){
	return em.find(Pagamento.class, id);}
	
	public void remover(Long id){
	Pagamento l = em.find(Pagamento.class,id);
	em.remove(l);}
        
        public List<Pagamento> consultar(){
        Query q =  em.createNamedQuery("123");
        return q.getResultList();
        }
}