/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author Caio
 */
public class LoginDAO{

	private EntityManager em;

	public LoginDAO(EntityManager em){
		this.em = em;
	}

//	public Login consultarPorEmail(String email){
//	return em.find(Login.class, email);}
//        
//        public Login consultarPorSenha(String senha){
//	return em.find(Login.class, senha);}
        
        //valor unique
        public List<String> consultarSenha(String Senha){
        Query q =  em.createNamedQuery("senha");
        q.setParameter(Senha, q);
        return q.getResultList();
        }
        //valor unique
        public List<String> consultarEmail(String Email){
        Query q = em.createNamedQuery("email");
        q.setParameter(Email, q);
        return q.getResultList();
        }
}