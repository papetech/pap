/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pap.dao;

import pap.classe.Pedido;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 *
 * @author Caio
 */
public class PedidoDAO{

	private EntityManager em;

	public PedidoDAO(EntityManager em){
		this.em = em;
	}
	
	public Pedido salvar(Pedido l){
	if(l.getId() == null){
            em.persist(l);
}else{
	l = em.merge(l);
}
	return l;}

	public Pedido consultarPorId(Long id){
	return em.find(Pedido.class, id);}
	
	public void remover(Long id){
	Pedido l = em.find(Pedido.class,id);
	em.remove(l);}
        
        public List<Pedido> consultar(){
        Query q =  em.createNamedQuery("123");
        return q.getResultList();
        }
}